class List < ApplicationRecord
    has_one_attached :image #imageはアップロードする画像のカラム名
end
